document.getElementById("toggleSidebar")
.addEventListener("click", function() {
    document.querySelector(".sidebar").classList.toggle("active");
});