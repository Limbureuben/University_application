<?php
include("dbconnection.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>management</title>
</head>
<style>
    #customers {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 80%;
        margin-top: 60px;
        margin-left: 261px;
        padding-right: 50px;
    }

    #customers td,
    #customers th {
        border: 1px solid #ddd;
        padding: 8px;
    }

    #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: darkslategray;
        color: white;
    }

    #customers tr:hover {}

    #customers tr:nth-child(even) {
        background-color: #f2f2f2;
    }


    .update {
        background-color: lightseagreen;
        cursor: pointer;
        border-radius: 0px;
        padding: 5px;
        margin-left: 5px;
    }

    .heading {
        text-align: center;
        color: blue;
    }
</style>

<body>
    <?php include("user.php") ?>
    <div class="heading">
        <h2>ADMIN MANAGEMENT SYSTEM</h2>
    </div>

    <table id="customers">
        <tr>
            <th>#number</th>
            <th>COURSE ABBREVIATION</th>
            <th>FULL COURSE NAME</th>
            <th>DURATION OF STUDY</th>
            <th>ACTION</th>
        </tr>

        <?php
        $count = 1;

        $select_all_users = "select * from courses";

        $result = mysqli_query($conn, $select_all_users);
        $number = mysqli_num_rows($result);
        if ($number > 0) {
            while ($row = mysqli_fetch_assoc($result)) {  ?>
                <tr>
                    <td><?php echo $count++ ?></td>

                    <td><?php echo $row['couName']; ?></td>

                    <td><?php echo $row['courseName']; ?></td>

                    <td><?php echo $row['Duration']; ?></td>
                    <td>
                        <a href="#"><button type="button" class="update">Viewed</button></a>
                    </td>
                </tr>
        <?php }
        } else {
            echo "0 results";
        } ?>

    </table>
</body>

</html>