<?php
include("dbconnection.php");
session_start();


if (isset($_POST['login'])) {
    $name = $_POST['name'];
    $password = md5($_POST['password']);

    $select_user_data_for_login =
        mysqli_query($conn, "SELECT * FROM `students` WHERE `name` = '$name' AND `password` = '$password'");

    $row = mysqli_num_rows($select_user_data_for_login);

    if ($row > 0) {

        echo "<script> alert('you are successfully login')</script>";
        echo "<script>window.location='userhome.php'</script>";
    } else {
        echo "<script>alert('wrong! invald email or password')</script>";
        echo "<script>window.location='html.php'</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="try.css">
</head>

<body>
    <div class="center">
        <h1>Login</h1>
        <form name="myForm" action="" onsubmit="return validateForm()" method="post">
            <div class="txt_field">
                <input type="text" name="name">
                <label>Username</label>
            </div>

            <div class="txt_field">
                <input type="password" name="password" required>
                <label>Password</label>
            </div>

            <div class="pass">Forgot password?</div>
            <input type="submit" name="login" value="login">
            <div class="signup_Link">
                Not a member?<a href="signup2.php">Signup</a>
            </div>
    </div>
    </div>
</body>

</html>