<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>addcourse</title>
    <link rel="stylesheet" type="text/css" href="addcourse.css">
</head>

<body>

    <div class="container">
        <form action="" method="POST">
            <h1>ADD COURSE</h1>
            <div class="form-group">
                <label for="">COURSE ABBREVIATION</label>
                <input type="text" name="couName" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="">NAME COURSE</label>
                <input type="text" name="courseName" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="">DURATION</label>
                <input type="text" name="Duration" class="form-control" required>
            </div>
            <button type="submit" name="insert_applicant_data" class="btnn">ADD</button>

        </form>
    </div>

</body>

</html>