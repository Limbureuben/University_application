<?php
include("dbconnection.php");

if (isset($_POST["insert_applicant_data"])) {
    $firstName = $_POST['firstName'];
    $secondName = $_POST['secondName'];
    $course = $_POST['course'];

    $enroll_new_student = "INSERT INTO registration(firstName, secondName, course)
VALUES('$firstName', '$secondName', '$course');";

    if (mysqli_query($conn, $enroll_new_student)) {
        echo "<script> alert('Your details submitted')</script>";
        echo "<script>window.location='userhome.php'</script>";
    } else {
        echo "your submission denieded";
    }

    mysqli_close($conn);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="apply.css">
</head>

<body>
    <?php include("user.php"); ?>
    <div class="center">
        <h1>Application</h1>
        <form method="post">
            <div class="txt_field">
                <input type="text" name="firstName" required>
                <label>First name</label>
            </div>
            <div class="txt_field">
                <input type="text" name="secondName" required>
                <label>Second name</label>
            </div>
            <div class="txt_field">
                <input type="text" name="course" required>
                <label>Enter course</label>
            </div>

            <input type="submit" name="insert_applicant_data" value="Submit">
    </div>
    </div>
</body>

</html>