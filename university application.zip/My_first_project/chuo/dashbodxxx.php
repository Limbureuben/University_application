<?php
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>studentDashboard</title>
    <style>
        body {
          margin: 0;
          font-family: "Lato", sans-serif;
        }
        
        .sidebar {
          margin: 0;
          padding: 0;
          width: 200px;
          background-color: #f1f1f1;
          position: fixed;
          height: 100%;
          overflow: auto;
        }
        
        .sidebar a {
          display: block;
          color: black;
          padding: 16px;
          text-decoration: none;
        }
         
        .sidebar a.active {
          background-color: #04AA6D;
          color: white;
        }
        
        .sidebar a:hover:not(.active) {
          background-color: #555;
          color: white;
        }
        
        div.content {
          margin-left: 200px;
          padding: 1px 16px;
          height: 1000px;
        }
        
        @media screen and (max-width: 700px) {
          .sidebar {
            width: 100%;
            height: auto;
            position: relative;
          }
          .sidebar a {float: left;}
          div.content {margin-left: 0;}
        }
        
        @media screen and (max-width: 400px) {
          .sidebar a {
            text-align: center;
            float: none;
          }
        }
        </style>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
         
</head>
<body>
    

<!-------my side bar here-->
    <div class="sidebar">
        <a class="active" href="">Admin Dsh</a>
        <a href="#news"></a>
        <?php

         $select_user = "select * from users where role='ADMIN' limit 1";

         $result = mysqli_query($conn,$select_user);
                 $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   

        <a href="adminProfile.php?id=<?php echo $row['id']?>">Your Profile</a>

        <?php }}?>


        <a href="status.php">Manage Course</a>
        <a href="status.php">Manage Application</a>
        <a href="usersAccount.php">Registered Account</a>
        <a href="logout.php">Feedback</a>
        <a href="logout.php">Logout</a>
      </div>
      
      <div class="content">
    
        <div class="container text-center" style="margin-top: 120px;">
             <div class="row">
                <div class="col-md-4">
                    <div class="card-one" style="border-radius:10px;background-color:  #5d6d7e ;width: 300px;height: 200px;box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;;">
                     <br>
                     <h4>Total users available</h4>
                     <br>
                     <p style="font-size: 35px;">57656464</p>
                    </div>
                </div>

                \


                <div class="col-md-4">
                    <div class="card-one" style="border-radius:10px;;background-color:  #5d6d7e ;width: 300px;height: 200px;box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;;">
                        <br>
                        <h4>Total students Registered</h4>
                        <br>
                        <p style="font-size: 35px;">  

                        <?php

                           $countUsers = mysqli_query($conn,  "select id from users where role='STUNDENT'" );
                                $user = mysqli_num_rows($countUsers);

                                    if(empty($user) >= 0) {      ?>
                                    
                                    <?php  echo $user; ?>

                                    
                            <?php } ?>

                        </p>
                       </div>
                </div>



                <div class="col-md-4">
                    <div class="card-one" style="border-radius:10px;background-color:  #5d6d7e ;width: 300px;height: 200px;box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px;;">
                        <br>
                        <h4>Total Feedbacks available</h4>
                        <br>
                        <p style="font-size: 35px;">273737656464</p>
                       </div>

                </div>
             </div>
          </div>
      </div>
      <!---ends-->
      



      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>