<?php
include("dbconnection.php");

$id = $_REQUEST['id'];
$query_for_select_user_row = "DELETE FROM students WHERE id= $id";

$result = mysqli_query($conn, $query_for_select_user_row);

header("Location:managementt.php");
exit();
