<?php
include("dbconnection.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive card layout</title>
    <link rel="stylesheet" type="text/css" href="card.css">
</head>

<body>
    <?php include("addash.php") ?>
    <div class="container">
        <div class="content-section">
            <div class="card">
                <img src="images (14).jpeg">
                <h2>Total user available</h2>
                <p>
                    <?php
                    $countusers = mysqli_query($conn, "select id from students");
                    $user = mysqli_num_rows($countusers);

                    if (empty($users) >= 0) { ?>

                        <?php echo $user; ?>

                    <?php } ?>
                </p>
            </div>
            <div class="card">
                <img src="images (14).jpeg">
                <h2>Registred students</h2>
                <p>
                    <?php
                    $countusers = mysqli_query($conn, "select id from registration");
                    $user = mysqli_num_rows($countusers);

                    if (empty($users) >= 0) { ?>

                        <?php echo $user; ?>

                    <?php } ?>
                </p>
            </div>
            <div class="card">
                <img src="images (14).jpeg">
                <h2>Total viewed students</h2>
                <p>
                    <?php
                    $countusers = mysqli_query($conn, "select id from students");
                    $user = mysqli_num_rows($countusers);

                    if (empty($users) >= 0) { ?>

                        <?php echo $user; ?>

                    <?php } ?>
                </p>
            </div>
        </div>
    </div>
</body>

</html>