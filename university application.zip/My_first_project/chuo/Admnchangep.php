<?php
include("dbconnection.php");

//codes to change password............

if (isset($_POST["change_password"])) {
    $password = md5($_POST['password']);
    $newpass = md5($_POST['newpass']);

    $updation = $mysqli_query($conn, "SELECT password from admin where password='$password'");

    $num = mysqli_fetch_array($updation);
    if ($num > 0) {
        $conn = mysqli_query($conn, "update admin set password='$newpass'");

        echo '<script>alert("Password Changed Successfully !!")</script>';
        echo '<script>window.location="addash.php"</script>';
    } else {
        echo '<script>alert("Current Password not match !!")</script>';
        echo '<script>window.location="Admnchangep.php"</script>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Adminchngep.css">
    <title>Change password</title>
</head>

<body>
    <form>
        <div class="form">
            <h2>Password update</h2>
            <input type="password" name="password" id="password" placeholder="Current password">
            <input type="password" name="newpass" id="password" placeholder="New password">
            <button type="submit" name="change_password" class="btnn"><a>CHANGE PASSWORD</a></button>
        </div>
        </div>
    </form>
</body>

</html>