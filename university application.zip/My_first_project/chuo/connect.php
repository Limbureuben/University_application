<?php
include("dbconnection.php");

if (isset($_POST["register"])) {

    $name = $_POST["name"];
    $course = $_POST["course"];
    $university = $_POST["university"];


    $register_the_student = "INSERT INTO registration(name, course, university) VALUES('$name', '$course', '$university');";

    if (mysqli_query($conn, $register_the_student)) {

        echo "<script> alert('you are successfully making an application')</script>";
        echo "<script>window.location='user.php'</script>";
    }
}

?>







<!DOCTYPE html>
<html lang="en">

<head>
    <title>create</title>
    <link href="application.css" rel="stylesheet">
    <form action="" method="post">
</head>

<body>
    <h1 style="color:brown; font: size 18px; text-align:center;">STUDENT REQUEST</h1>
    <div class="form">
        <input type="text" name="name" placeholder="Enter full Name" required><br><br><br>
        <input type="text" name="course" placeholder="course" required>
        <input type="text" name="university" placeholder="university" required>
        <button type="submit" name="register" class="btnn"><a>SUBMIT</a></button>
    </div>
</body>

</html>