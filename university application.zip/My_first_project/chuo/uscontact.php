<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Contact</title>
        <link rel="stylesheet" href="ucontact.css">
        <link rel="stylesheet" href="footer.css">
    </head>
    <body>
        <div class="header">
            <h2><b> Visit us on social media for more details</b></h2>
        </div>
        <div class="form">
            <h2>#MASTER PLANN II</h2>
            <h3><br>
        Instagram: limbureuben<br><br><br>
    WhatsApp:  +255625219727, +255658907176<br><br><br>
    Call:  +255625219727, +25522172507<br><br><br>
    Email:  limbureubenn@gmail.com<br><br><br>
    Twitter: #Masterplann</h3>
        </div>
    </body>
</html>
