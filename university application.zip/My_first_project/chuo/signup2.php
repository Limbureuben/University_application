<?php
include_once "dbconnection.php";

if (isset($_POST["insert_user_data"])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $enroll_new_student = "INSERT INTO students (name, email, password)
    VALUES('$name', '$email', '$password');";


    if (mysqli_query($conn, $enroll_new_student)) {

        echo "<script>window.location='userhome.php'</script>";
    } else {
        echo "wrong try again";
    }

    mysqli_close($conn);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <form action="" method="POST">
        <title>signup</title>
        <link rel="stylesheet" href="try2.css">
</head>

<body>
    <div class="center">
        <h1>Sign-up</h1>
        <form method="post">
            <div class="txt_field">
                <input type="text" name="name" required>
                <label>Username</label>
            </div>
            <div class="txt_field">
                <input type="text" name="email" required>
                <label>E-mail</label>
            </div>
            <div class="txt_field">
                <input type="Password" name="password" required>
                <label>Password</label>
            </div>
            <input type="submit" name="insert_user_data" value="Sign-up">
    </div>
    </div>
</body>

</html>