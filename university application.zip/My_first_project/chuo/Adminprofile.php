<?php
include("dbconnection.php");
//codes to update details.....

if (isset($_POST["updateadminProfile"])) {
    $password = md5($_POST["password"]);
    $newpass = md5($_POST["newpass"]);

    $updation = $mysqli_query($conn, "SELECT password from admin where password='$password'");

    $num = mysqli_fetch_array($updation);
    if ($num > 0) {
        $conn = mysqli_query($conn, "update admin set password='$newpass'");

        echo '<script>alert("Password Changed Successfully !!")</script>';
        echo '<script>window.location="addash.php"</script>';
    } else {
        echo '<script>alert("Current Password not match !!")</script>';
        echo '<script>window.location="Admnchangep.php"</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin profile</title>
    <link rel="stylesheet" href="adminprofile.css">
</head>

<body>
    <div class="container">
        <h1>Admin profile</h1>
        <form action="" method="POST">
            <?php

            $select_admin = "select * from admin where id = '" . $_GET['id'] . "'";
            $result = mysqli_query($conn, $select_admin);
            $number = mysqli_num_rows($result);
            if ($number > 0) {
                while ($row = mysqli_fetch_assoc($result)) {  ?>

                    <div class="form-group">
                        <label for="">Name</label><br>
                        <input type="text" name="name" value="<?php echo $row['name']; ?>" class="form-control required">
                    </div>
                    <div class="form-group">
                        <label for="">E-mail</label><br>
                        <input type="text" name="email" value="<?php echo $row['email']; ?>" class="form-control required">
                    </div>
                    <div class="form-group">
                        <label for="">Current password</label>
                        <input type="password" name="password" value="<?php echo $row['password']; ?>" class="form-control required">
                    </div>
                    <div class="form-group">
                        <label for="">New-password</label>
                        <input type="password" name="password" maxlength="10" class="form-control required">
                    </div>
            <?php }
            } ?>
            <input type="submit" name="updateadminProfile" class="btn" value="update">
        </form>
    </div>

</body>

</html>