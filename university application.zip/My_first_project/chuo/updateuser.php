<?php
include("dbconnection.php");

if (isset($_POST["update"])) {

    $id = $_GET["id"];
    $name = $_POST["name"];
    $email = $_POST["email"];


    $update_user = "UPDATE users SET  name='$name',email='$email'
    WHERE  id='$id'";

    if (mysqli_query($conn, $update_user)) {
        header("location:managementt.php");
        exit();
    } else {
        echo "wrong updation try again";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
</head>

<body>

    <div class="container-fluid" style="margin-top:100px">
        <form action="" method="post">

            <?php
            $select_user = "select * from users where id = '" . $_GET['id'] . "'";
            $result = mysqli_query($conn, $select_user);
            $number = mysqli_num_rows($result);
            if ($number > 0) {
                while ($row = mysqli_fetch_assoc($result)) {  ?>

                    <div class="form-group">
                        <label for="exampleInputPassword1">Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo $row['name']; ?>" id="exampleInputPassword1" placeholder="name">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input type="email" name="email" class="form-control" id="exampleInputEmail1" value="<?php echo $row['email']; ?>" aria-describedby="emailHelp" placeholder="Enter email">
                    </div>

            <?php  }
            } ?>
            <hr>

            <button type="submit" name="update" class="btn btn-primary">Update</button>
        </form>


    </div>
    <div>
        <br>
        <center><button type="submit" class="btn btn-warning"><a href="usersAccount.php">Home</a></button></center>
    </div>







</body>

</html>