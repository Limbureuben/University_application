<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>School Registration system</title>
    <link rel="stylesheet" href="index.css">
</head>

<body>
    <div class="navbar">
        <div class="icon">
            <div class="logo">
                <h2>UNIVERSITY APPLICATION SYSTEM</h2>
            </div>
            <div class="menu">
                <ul>
                    <li><a href="html.php">STUDENT</a></li>
                    <li><a href="admin2.php">ADMIN</a></li>
                </ul>
            </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <div class="body">
                <h2><span>Dear Students & users</span><br>
                    <div class="par">welcome to the university application<br>
                        system
                        Visit our webpage to register and make an application.<br>
                </h2>
            </div>
        </div>
    </div>

    </div>
</body>

</html>