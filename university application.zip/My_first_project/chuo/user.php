<?php
include("dbconnection.php");
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>User dashboard</title>
    <link rel="stylesheet" href="userdas.css">
    <form action="#" method="post">
</head>

<body>
    <div class="sidebar">
        <header>USERS</header>
        <ul>
            <li><a href="userhome.php">Home & About-us</a></li>
            <li><a href="courseadd.php">Course Available</a></li>
            <li><a href="application.php">Application</a></li>
            <li><a href="#">User-Profile</a></li>
            <li><a href="#">Selected students</a></li>
            <li><a href="logoutttt.php">Logout</a></li>
        </ul>
    </div>
</body>

</html>