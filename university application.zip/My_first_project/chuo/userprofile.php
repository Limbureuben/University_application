<?php
include("dbconnection.php");
//codes to update details.....

if (isset($_POST["change_password"])) {
    $password = md5($_POST["password"]);
    $newpass = md5($_POST["newpass"]);

    $updation = $mysqli_query($conn, "SELECT password from students where password='$password'");

    $num = mysqli_fetch_array($updation);
    if ($num > 0) {
        $conn = mysqli_query($conn, "update admin set password='$newpass'");

        echo '<script>alert("Password Changed Successfully !!")</script>';
        echo '<script>window.location="user.php"</script>';
    } else {
        echo '<script>alert("Current Password not match !!")</script>';
        echo '<script>window.location="userprofile.php"</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="userprofile.css">
</head>

<body>
    <div class="center">
        <h1>USER PROFILE</h1>
        <form method="post">
            <?php

            $select_user = "select * from students where id = '" . $_GET['id'] . "'";

            $result = mysqli_query($conn,  $select_user);

            $number = mysqli_num_rows($result);

            if ($number > 0) {
                while ($row = mysqli_fetch_assoc($result)) {  ?>

                    <div class="txt_field">
                        <input type="text" type="text" name="name" value="<?php echo $row['name']; ?>">
                    </div>
                    <div class="txt_field">
                        <input type="text" type="text" name="email" value="<?php echo $row['email']; ?>">
                    </div>
                    <div class="txt_field">
                        <lable>Current password</lable>
                        <input type="password" type="text" name="password" value="<?php echo $row['password']; ?>">
                    </div>
                    <div class="txt_field">
                        <input type="password" type="text" maxlength="10" name="password" required>
                    </div>
            <?php }
            } ?>
            <input type="submit" name="change_password" value="UPDATE">
    </div>
    </div>
    </div>
</body>

</html>