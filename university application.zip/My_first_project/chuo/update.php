<?php
include("dbconnection.php");

if (isset($_POST["update"])) {

    $id = $_GET["id"];
    $name = $_POST["name"];
    $email = $_POST["email"];


    $update_user = "UPDATE users SET  name='$name',email='$email'
    WHERE  id='$id'";

    if (mysqli_query($conn, $update_user)) {
        header("location:managementt.php");
        exit();
    } else {
        echo "wrong updation try again";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>updation</title>
    <link rel="stylesheet" href="updateuser.css">
</head>

<body>
    <form>
        <form action="" method="post"></form>

        <?php
        $select_user = "select * from users where id = '" . $_GET['id'] . "'";
        $result = mysqli_query($conn, $select_user);
        $number = mysqli_num_rows($result);
        if ($number > 0) {
            while ($row = mysqli_fetch_assoc($result)) {  ?>

                <div class="form">
                    <label for="username" class="username">User name</label>

                    <input type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="name">



                    <label for="useremail" class="useremail">Email</label>

                    <input type="text" name="email" value="<?php echo $row['email']; ?>" placeholder="email">

            <?php  }
        } ?>
            <hr>
            <button type="submit" name="update" class="btnn"><a>Update</a></button>
                </div>
    </form>

</body>

</html>