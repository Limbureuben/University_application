<footer>
        <div class="containerr">
            <div class="row">
                <div class="col-md-12">
                    &copy; <?php echo date('Y');?> University Application System | By : <a href="http://www.phpreuben.com/" target="_blank">ReubenLimbu</a>
                </div>
            </div>
        </div>
    </footer>