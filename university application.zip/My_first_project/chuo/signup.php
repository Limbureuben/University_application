<?php
include("dbconnection.php");

if (isset($_POST["insert_user_data"])) {
    $name  = $_POST['name'];
    $email  = $_POST['email'];
    $password  = md5($_POST['password']);

    $enroll_new_student = "INSERT INTO  users(name,email,password) VALUES('$name','$email','$password');";

    if (mysqli_query($conn, $enroll_new_student)) {

        echo "<script> alert('you are successfully sign-up')</script>";
        echo "<script>window.location='user.php'</script>";
    } else {
        echo "wrong  try again";
    }

    mysqli_close($conn);
}

//next is HTML ccodes..............................................
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="UTF-8">
    <link href="signup.css" rel="stylesheet">
    <form action="" method="POST">
        <title>Registration</title>
</head>

<body>
    <div class="form">
        <h2>STUDENT</h2>
        <input type="text" name="name" placeholder="Enter name" required>
        <input type="text" name="email" placeholder="Enter email" required>
        <input type="password" name="password" placeholder="Enter password" required>
        <button type="submit" name="insert_user_data" class="btnn"><a>SIGN-UP</a></button>
    </div>
</body>

</html>