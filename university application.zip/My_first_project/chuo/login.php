<?php
include("dbconnection.php");
session_start();


if (isset($_POST['login'])) {
    $name = $_POST['name'];
    $password = md5($_POST['password']);

    $select_user_data_for_login =
        mysqli_query($conn, "SELECT * FROM `#` WHERE `name` = '$name' AND `password` = '$password'");

    $row = mysqli_num_rows($select_user_data_for_login);

    if ($row > 0) {

        echo "<script> alert('you are successfully login')</script>";
        echo "<script>window.location='#'</script>";
    } else {
        echo "<script>alert('wrong! invald email or password')</script>";
        echo "<script>window.location='login.php'</script>";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>login</title>
    <link rel="stylesheet" href="login.css">
    <form action="" method="POST">
</head>

<body>
    <div class="form">
        <h2>LOGIN FORM</h2>
        <input type="text" name="name" id="name" placeholder="user name" require=true>
        <input type="password" name="password" id="password" placeholder="password" require>
        <button type="submit" name="login" class="btnn"><a>LOGIN</a></button>
    </div><br>
</body>

</html>