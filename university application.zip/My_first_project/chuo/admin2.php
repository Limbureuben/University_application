<?php
include("dbconnection.php");
session_start();

if (isset($_POST['loginn'])) {
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $select_admin_data_for_login = mysqli_query($conn, "SELECT * FROM `adminn` WHERE `email` = '$email' AND `password` = '$password'");

    $row = mysqli_num_rows($select_admin_data_for_login);

    if ($row > 0) {

        echo "<script> alert('you are successfully login')</script>";
        echo "<script>window.location='cards.php'</script>";
    } else {
        echo "<script>alert('wrong! invald email or password')</script>";
        echo "<script>window.location='admin2.php'</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>adminlogin</title>
    <link rel="stylesheet" href="admin2.css">
</head>

<body>
    <div class="center">
        <h1>Admin Login</h1>
        <form method="post">
            <div class="txt_field">
                <input type="text" name="email" required>
                <label>E-mail</label>

            </div>
            <div class="txt_field">
                <input type="password" name="password" required>
                <label>Password</label>
            </div>
            <div class="pass">Forgot password?</div>
            <input type="submit" name="loginn" value="login">
    </div>
    </div>
</body>

</html>