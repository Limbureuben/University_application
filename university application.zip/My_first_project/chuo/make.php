<?php
include("dbconnection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="make.css">
</head>

<body>
    <div class="center">
        <h1>Application</h1>
        <form method="post">
            <div class="txt_field">
                <input type="text" required>
                <label>First name</label>
            </div>
            <div class="txt_field">
                <input type="text" required>
                <label>Second name</label>
            </div>
            <label>Select course</label>
            <select>
                <option>--Choose Course---</option>
                <option>ARDHI UNIVERSITY</option>
                <option>UNIVERSITY OF DARSARAM</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF DARSARAM</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF ARDHI</option>
                <option>UNIVERSITY OF ARDHI</option>
            </select><br><br>
            <hr>
            <input type="submit" name="login" value="Submit">
    </div>
    </div>
</body>

</html>