<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE-edge">
        <meta name="viewpoint" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="userpro.css">
        <title>USER PROFILE</title>
    </head>
    <body>
         <div class="logo"></div>
        <div class="form">
            <h2>USER PROFILE</h2><br><br>
            <?php include 'profile_display.php'; ?>
        </form>
    </body>
</html>
