<?php
    $name = $_POST['name'];
    $university = $_POST['university'];
    $course = $_POST['course'];

    //database connection.......
    $conn = new mysqli('localhost', 'root', '', 'chuo');
    if ($conn->connect_error) {
        die('connection failed:' .$conn->connect_error);
    } else {
        $stmt = $conn->prepare('insert into registration(name, university, course) values(?,?,?)');
        $stmt->bind_param("sss", $name, $university, $course);
        $stmt->execute();
        echo "<h2>" . "Thanks" . " " . $name ." " ."Your application succesfully!!!" ."</h2>";
        $stmt->close();
    }
?>

