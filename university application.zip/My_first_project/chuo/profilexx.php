<?php
include("connection.php");

if(isset($_POST["updateadminProfile"])){

    $id =$_GET["id"];
     $name =$_POST["name"];
      $email =$_POST["email"];
    $password =md5($_POST["password"]);


 $update_adminprofile = "UPDATE users SET  name='$name',email='$email',password='$password'
    WHERE  id='$id'";

    if (mysqli_query($conn, $update_adminprofile)) {
           header("location:adminDshboard.php");
           exit();
    } else {
        echo "wrong updation try again";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>studentDashboard</title>
    <style>
        body {
          margin: 0;
          font-family: "Lato", sans-serif;
        }
        
        .sidebar {
          margin: 0;
          padding: 0;
          width: 200px;
          background-color: #f1f1f1;
          position: fixed;
          height: 100%;
          overflow: auto;
        }
        
        .sidebar a {
          display: block;
          color: black;
          padding: 16px;
          text-decoration: none;
        }
         
        .sidebar a.active {
          background-color: #04AA6D;
          color: white;
        }
        
        .sidebar a:hover:not(.active) {
          background-color: #555;
          color: white;
        }
        
        div.content {
          margin-left: 200px;
          padding: 1px 16px;
          height: 1000px;
        }
        
        @media screen and (max-width: 700px) {
          .sidebar {
            width: 100%;
            height: auto;
            position: relative;
          }
          .sidebar a {float: left;}
          div.content {margin-left: 0;}
        }
        
        @media screen and (max-width: 400px) {
          .sidebar a {
            text-align: center;
            float: none;
          }
        }
        </style>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
         
</head>
<body>
    

<!-------my side bar here-->
    <div class="sidebar">
        <a class="active" href="">Admin profile</a>
       <br>
        <a href="admin.html">BacK Home</a>
      </div>
      
      <div class="content">
    
        <div class="container"  style="width: 700px;">
            <h2>Update your password</h2>
            <form class="form-horizontal" action="" method="POST">

               <?php
                $select_user = "select * from users where id = '" .$_GET['id']. "'";
                $result = mysqli_query($conn, $select_user);
                $number = mysqli_num_rows($result);
                 if ($number > 0) {
                     while($row = mysqli_fetch_assoc($result)) {  ?>   

              <div class="form-group">
                <label class="control-label col-sm-2" for="name">Name:</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="name" value="<?php echo $row['name']; ?>" placeholder="" name="name">
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Email:</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="email" value="<?php echo $row['email']; ?>" placeholder="Enter password" name="email">
                </div>
              </div>

              <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Old-Password:</label>
                <div class="col-sm-10">
                  <input type="password" class="form-control" id="pwd" value="<?php echo $row['password']; ?>" placeholder="Enter password">
                </div>
              </div>

                <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">New-Password:</label>
                <div class="col-sm-10">
                  <input type="password" name="password" maxlength="10" required class="form-control" id="pwd" placeholder="Enter password">
                </div>
              </div>
              
        <?php }}?>
            
              <div class="form-group">        
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" name="updateadminProfile" class="btn btn-default">Submit</button>
                </div>
              </div>
            </form>
          </div>
          
      </div>
      <!---ends-->
      



      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>