<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>User dashboard</title>
    <link rel="stylesheet" href="addash.css">
    <form action="#" method="post">
</head>

<body>
    <div class="sidebar">
        <header>Admin</header>
        <ul>
            <li><a href="cards.php">Dashboard</a></li>
            <li><a href="managementt.php">Manage Accounts</a></li>
            <li><a href="usersaccount.php">Registred Users</a></li>
            <?php

            $select_admin = "select * from admin where id=1";

            $result = mysqli_query($conn, $select_admin);
            $number = mysqli_num_rows($result);
            if ($number > 0) {
                while ($row = mysqli_fetch_assoc($result)) {  ?>

                    <li><a href="Adminprofile.php?id=<?php echo $row['id'] ?>">Admin profile</a></li>

            <?php }
            } ?>
            <li><a href="addcourse.php">Add course</a></li>
            <li><a href="Alogout.php">Logout</a></li>

        </ul>
    </div>
</body>

</html>