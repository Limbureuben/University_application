<?php
include("dbconnection.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    #customers {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 80%;
        margin-top: 60px;
        margin-left: 261px;
        padding-right: 50px;
    }

    #customers td,
    #customers th {
        border: 1px solid #ddd;
        padding: 8px;
    }

    #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: darkslategray;
        color: white;
    }

    #customers tr:hover {}

    #customers tr:nth-child(even) {
        background-color: #f2f2f2;
    }


    .delete {
        background-color: red;
        cursor: pointer;
        border-radius: 8px;
    }

    .update {
        background-color: #04AAA6;
        cursor: pointer;
        border-radius: 8px;
    }

    .heading {
        text-align: center;
        color: blue;
    }

    .cancel {
        background-color: red;
        cursor: pointer;
        border-radius: 0px;
        padding: 5px;
        margin-left: 25px;
    }

    .confirm {
        background-color: lightseagreen;
        cursor: pointer;
        border-radius: 0px;
        padding: 5px;
        margin-left: 25px;

    }
</style>

<body>

    <?php include("addash.php") ?>

    <div class="heading">
        <h2>USER ACCOUNTS</h2>
    </div>
    <table id="customers">
        <tr>
            <th>#number</th>
            <th>NAME</th>
            <th>COURSE</th>
            <th>UNIVERSITY</th>
            <th>ACTION</th>
        </tr>

        <?php
        $count = 1;

        $registered_students = "select * from registration";

        $result = mysqli_query($conn, $registered_students);
        $number = mysqli_num_rows($result);
        if ($number > 0) {
            while ($row = mysqli_fetch_assoc($result)) {  ?>
                <tr>
                    <td><?php echo $count++ ?></td>

                    <td><?php echo $row['firstName']; ?></td>

                    <td><?php echo $row['secondName']; ?></td>

                    <td><?php echo $row['course']; ?></td>

                    <td>
                        <a href="#"><button type="button" class="confirm">Confirm</button></a>
                        <span><a href="#"><button type="button" class="cancel">Cancel</button></a></span>
                    </td>
                </tr>
        <?php }
        } else {
            echo "0 results";
        } ?>

    </table>
</body>

</html>