<!DOCTYPE html>
<html lang="en">
    <head>
        <title>about</title>
        <link href="about.css" rel="stylesheet">
        <link href="footer.css" rel="stylesheet">
    </head>
    <form>
        <fieldset>
            <div class="about">
                <h1>ABOUT US</h1>
                <div class="page">
                    <h3>WHO WE ARE</h3>
                    <a>We are system developers.
                     We have been developing system and
                     application with the use of our professional IT since 2020<br><a>
                    We are ploud Hubspot platinum partner on using
                    the best tools to help our clients succeed. <span><b>Our team</b></span> is made 
                        up of smart</a><br><a> and talented people that are passionate
                         about deshning and developing a system.
                    </a>
                    <h3>WE ARE DIFFERENT THAN THE REST</h3>
                    <a><b>We are rooted in system development.</b> Our parent company,
                     <span><b>The center for system development(CSD)</b></span>, has been helping<br><a> developing
                     system organizations turn talent into performance for almost 40 years. Unlike other
                     company, we are obsessed <br><a> with ROI and we have experiance to develop inbound system
                      because we have done it ourselves...<br></a>
                      <a><b>We have been where you are</b>. More than a decade ago, where we needed to
                         develop a system of a company, we turned now<br><a> inbound development and found a hige success
                     after launching our<span><b> professional  as business</b></span>. Once we mastered the art<br><a> of using 
                    thought leadership for leading generation, we launched <span><b>#Masterplann</b></span> so we could help
                     bussiness do the same thing.</b></span></a>
                     <div class="button">
                        <button class="btnn"><a>LEADG2 NUMBER</a></button>
                        <button class="btn"><a href="uscontact.php">CONTACT US</a></button>
                     </div>
                </div>
            </div>
        </fieldset>
    </form>
    <body>

    </body>
</html>