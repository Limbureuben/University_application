<?php
// include your database connection here.......

include 'db_connection.php';

//get user ID here from URL

$user_id = $_POST['id'];

//Query to retrive user data fro the database....

$query = "SELECT * FROM user WHERE id = $user_id";
$result = mysqli_query($connection, $query);

if (!$result) {
    die ("Database query failed:" . mysqli_error($connection));
}

//fetch user data.......

$row = mysqli_fetch_assoc($result);

//display user information ......
echo "<h2>{$row ['username']}</h2>";
echo "<p>Email: {$row['email']}</p>";

//close the database connection....

mysqli_close($connection)
?>