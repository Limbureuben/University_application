<?php
include("dbconnection.php");
if (isset($_POST['SUBMIT']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = mysqli_query($con, "select email form user where email='$email'");
    $num=mysqli_fetch_array($query);
    if ($num>1)
    {
        echo "<script>alert('Email-id already register with us. Please try with diffrent email id.');</script>";
  echo "<script>window.location.href='registration.php'</script>";
    }
    else
    {
        mysqli_query($con,"insert into user(name,email,password,mobile,gender) values('$name','$email','$password','$mobile','$gender')");
echo "<script>alert('Successfully register with us. Now you can login');</script>";  
echo "<script>window.location.href='login.php'</script>";
}
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <meta charset="UTF-8">
        <link href="registrationn.css" rel="stylesheet">
        <form action="" method="post">
        <title>Registration</title>
    </head>
        <body>
            <body background="images.jpeg">
            <div class="form">
                <h2>STUDENT</h2>
                        <input type="text" name="name" placeholder="Enter name" required>
                        <input type="text" name="email" placeholder="Enter email" reauired>
                        <input type="password" name="" placeholder="Enter password" required>
                        <button class="btnn"><a>SUBMIT</a></button>
            </div>

        </body>
    </head>
</html>