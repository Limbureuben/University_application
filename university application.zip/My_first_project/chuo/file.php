<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>User dashboard</title>
    <link rel="stylesheet" href="file.css">
    <link rel="stylesheet" href="footer.css">
    <form action="#" method="post">
</head>

<body>
    <div class="sidebar">
        <header>USERS</header>
        <ul>
            <li><a href="">Dashboard</a></li>
            <li><a href="">Courses</a></li>
            <li><a href="#">Application</a></li>
            <li><a href="">Profile</a></li>
            <li><a href="#">C password</li>
            <li><a href="logoutttt.php">Logout</a></li>
        </ul>
    </div>

</body>

</html>