<?php
include("dbconnection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="userhome.css">
</head>

<body>
    <?php include("user.php") ?>
    <div class="main">
        <div class="content">
            <h1><span>Welcome to University application</span><br>
                visit our website</h1>
            <p div class="par">
                #Master company already desgned & developed a number of system
                <br> If you are interested to be together with us click Join-us button<br>
                so just join us to vist our website for more information.
            </p>
            <button class="cn"><a href="#">ABOUT US</a></button><br>
            <button class="cn" type="button" onclick="document.getElementById('demo').innerHTML =Date()">
                Time and Date</button>
            <p id="demo"></p>


        </div>
    </div>
    </div>
    </div>
</body>

</html>