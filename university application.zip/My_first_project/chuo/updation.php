<?php
include("dbconnection.php");

if (isset($_POST["updateuser"])) {
    $id = $_GET["id"];
    $name = $_POST["name"];
    $email = $_POST["email"];

    $update_user = "UPDATE students SET name='$name', email='$email' WHERE id='$id'";

    if (mysqli_query($conn, $update_user)) {
        header("location:managementt.php");
        exit();
    } else {
        echo "Wrong updation try again";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>admin profile</title>

    <link rel="stylesheet" href="updation.css">
</head>

<body>
    <div class="container">
        <h1>UPDATE USER</h1>
        <form action="" method="post">
            <?php
            $select_user = "select * from students where id='" . $_GET['id'] . "'";
            $result = mysqli_query($conn, $select_user);
            $number = mysqli_num_rows($result);
            if ($number > 0) {
                while ($row = mysqli_fetch_assoc($result)) { ?>

                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" name="name" value="<?php echo $row['name']; ?>" class="form-control required">
                    </div>
                    <div class="form-group">
                        <label for="">E-mail</label>
                        <input type="text" name="email" value="<?php echo $row['email']; ?>" class="form-control required">
                    </div>
            <?php }
            } ?>
            <input type="submit" name="updateuser" class="btn" value="update">
        </form>
    </div>

</body>

</html>